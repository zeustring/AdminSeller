<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cliente;
class MisClientesController extends Controller
{
    public function index()
    {	$MisClientes     =    Cliente::all();
    	return view('MisClientes.Index',['MisClientes' => $MisClientes]);
    }
}
