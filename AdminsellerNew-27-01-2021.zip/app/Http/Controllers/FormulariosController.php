<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Estado;
use App\Municipio;
use App\Colonia;
use App\Ciudad;
use App\Sucursal;
use App\Jerarquia;
use App\Canal;
class FormulariosController extends Controller
{
    public function SucursalRegistro()
    {	$colonias      =    Colonia::all();
        $estados       =    Estado::all();
        $ciudades      =    Ciudad::all();
    	return view('Formularios.SucursalRegistro',['estados'  => $estados,
                                                  'ciudades' => $ciudades,
                                                  'colonias' => $colonias]);
    }

    public function Municipios($idEstado)
    {
    	$municipios   =    Municipio::where('id_estado','=',$idEstado)->get();
    	return view('Formularios.SelectMunicipio',['municipios'=>$municipios]);
    }
    public function Colonias($idMunicipio)
    {
    	$colonias   =    Colonia::where('id_municipio','=',$idMunicipio)->get();
    	return view('Formularios.SelectColonia',['colonias'=>$colonias]);
    }
    public function EstadosFormulario()
    {
        return view('Formularios.EstadosRegistro');
    }
    public function CiudadesFormulario()
    {
        $estados   =   Estado::all();
        return view('Formularios.CiudadesRegistro',['estados'=> $estados]);
    }

    public function ColoniasFormulario()
    {
        $estados   =   Estado::all();
        $ciudades  =   Ciudad::all();
        return view('Formularios.ColoniasRegistro',['estados'=> $estados,
                                                    'ciudades'=> $ciudades]);
    }

    public function EmpleadoRegistro()
    {
        $sucursales   =    Sucursal::all();
        $jerarquias   =    Jerarquia::all();
        $canal        =    Canal::all();
        return view('Formularios.EmpleadoRegistro',['sucursales'  => $sucursales,
                                                    'jerarquias'  => $jerarquias,
                                                    'canales'       => $canal]);
    }
    public function ClientesRegistro()
    {
        return view('Formularios.ClientesRegistro');
    }
}
