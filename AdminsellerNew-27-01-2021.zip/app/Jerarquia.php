<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jerarquia extends Model
{
    protected $table     =  "jerarquias";
    protected $filable   =  ['nombre'];
}
